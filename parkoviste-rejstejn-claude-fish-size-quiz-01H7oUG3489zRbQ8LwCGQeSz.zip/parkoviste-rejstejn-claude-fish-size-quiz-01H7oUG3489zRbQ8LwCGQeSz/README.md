# Parkovište Rejštejn - MVP Parkovací Systém

MVP webové aplikace pro správu městských/soukromých parkovišť bez fyzických automatů. Systém funguje na principu QR kódů - zákazník naskenuje QR kód, zadá SPZ, zaplatí online a dostane digitální doklad.

## 🚀 Tech Stack

- **Frontend:** Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **Backend:** Next.js API Routes + Server Actions
- **Databáze:** Firebase Firestore
- **Auth:** Firebase Authentication
- **Platby:** Stripe Checkout (Apple Pay / Google Pay)
- **PDF:** @react-pdf/renderer
- **Hosting:** Vercel

## 📦 Instalace

```bash
# Naklonuj repo
git clone <repo-url>
cd parkoviste-rejstejn

# Nainstaluj dependencies
npm install

# Zkopíruj .env.example do .env.local a vyplň hodnoty
cp .env.example .env.local
```

## 🔧 Konfigurace

### 1. Firebase Setup

1. Vytvoř projekt na [Firebase Console](https://console.firebase.google.com/)
2. Aktivuj **Firestore Database**
3. Aktivuj **Authentication** (Email/Password)
4. Ve **Project Settings** najdi web app credentials
5. Stáhni Service Account key (JSON) pro Admin SDK

Vyplň do `.env.local`:

```env
# Firebase Client
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=

# Firebase Admin (z Service Account JSON)
FIREBASE_ADMIN_PROJECT_ID=
FIREBASE_ADMIN_CLIENT_EMAIL=
FIREBASE_ADMIN_PRIVATE_KEY=
```

### 2. Stripe Setup

1. Vytvoř účet na [Stripe](https://stripe.com/)
2. Přepni do **Test Mode**
3. Získej API klíče z **Developers > API keys**
4. Nastav webhook endpoint: `https://your-domain.com/api/webhooks/stripe`
   - Events: `checkout.session.completed`, `checkout.session.expired`
5. Zkopíruj **Webhook Secret**

Vyplň do `.env.local`:

```env
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
```

### 3. App URL

```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

Pro production použij produkční URL (např. `https://parkoviste.vercel.app`)

## 🌱 Seed Data (Testovací data)

Pro vytvoření testovacího parkoviště:

```bash
# Nainstaluj tsx
npm install -D tsx

# Spusť seed script
npx tsx scripts/seed.ts
```

Script vytvoří:
- Testovacího klienta (Obec Rejštejn)
- Testovací parkoviště s URL pro QR kód

Po spuštění dostaneš URL pro testování (např. `http://localhost:3000/p/abc123`)

## 🏃 Spuštění

```bash
# Development server
npm run dev

# Production build
npm run build
npm start
```

Aplikace poběží na [http://localhost:3000](http://localhost:3000)

## 📱 Použití

### Zákaznický Flow

1. **Naskenuj QR kód** na parkovišti → otevře `/p/[parkingLotId]`
2. **Zadej SPZ** vozidla
3. **Klikni "Zaplatit"** → redirect na Stripe Checkout
4. **Zaplať kartou** (nebo Apple Pay / Google Pay)
5. **Success stránka** → možnost stáhnout PDF doklad

### Testování Stripe plateb

V test módu použij testovací karty:
- **Úspěšná platba:** `4242 4242 4242 4242`
- **Neúspěšná platba:** `4000 0000 0000 0002`
- CVC: jakékoliv 3 číslice
- Datum: jakékoliv budoucí datum

## 🗂️ Struktura projektu

```
/app
  /p/[parkingLotId]         # Veřejná stránka parkoviště
  /success                  # Po úspěšné platbě
  /failed                   # Po neúspěšné platbě
  /receipt/[ticketId]       # Stažení PDF dokladu
  /api
    /checkout               # Stripe checkout session
    /receipt/[ticketId]     # PDF generování
    /webhooks/stripe        # Stripe webhook
/components
  /parking                  # Komponenty pro parking stránky
  /pdf                      # PDF komponenty
/lib
  /firebase.ts              # Firebase client config
  /firebase-admin.ts        # Firebase admin config
  /stripe.ts                # Stripe config
  /db.ts                    # Database helpers
  /utils.ts                 # Utility funkce
/types
  /index.ts                 # TypeScript typy
```

## 🎨 Design

Design je **extrémně minimalistický** a **mobile-first**:
- Off-white pozadí (`#F8F8F8`)
- Tmavě červená akcentová barva (`#B91C1C`)
- Velké, touch-friendly prvky
- Zaoblené tlačítka (pill shape)
- System fonty

## 🔒 Bezpečnost

- ✅ Firebase Admin SDK pro server-side operace
- ✅ Stripe webhook signature verification
- ✅ Validace SPZ na FE i BE
- ✅ Stripe Checkout (PCI compliant)
- ✅ Environment variables pro citlivá data

## 🚢 Deployment na Vercel

1. Push na GitHub
2. Připoj repo na [Vercel](https://vercel.com)
3. Nastav Environment Variables (všechny z `.env.local`)
4. Deploy!

**Důležité:** Po deployi aktualizuj:
- `NEXT_PUBLIC_APP_URL` na produkční URL
- Stripe webhook URL na `https://your-domain.vercel.app/api/webhooks/stripe`

## 📝 TODO - Fáze 2 & 3

- [ ] Dashboard pro provozovatele
- [ ] QR kód generátor
- [ ] Auth + registrace
- [ ] Správa parkovišť
- [ ] Přehled lístků
- [ ] Landing page
- [ ] Superadmin panel
- [ ] Fakturace

## 📄 Licence

Soukromý projekt

---

**Made with ❤️ for Rejštejn**